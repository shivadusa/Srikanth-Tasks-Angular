import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular-Components';
  //Select Task Data
  public Countries:any[]=[
    {
       "id":1,
       "name":"India",
       "country_id":1
    },
  {
   
    "id":2,
    "name":"UK",
    "country_id":2
  }
];

 public States:any[]=[
    {
      "id":1,
      "name":"TS",
      "country_id":1,
      "state_id":1,
    },
    {
      "id":2,
      "name":"AP",
      "country_id":1,
      "state_id":2,
    },
    {
      "id":3,
      "name":'TN',
      "country_id":1,
      "state_id":3,
    },
    {
      "id":4,
      "name":'London',
      "country_id":2,
      "state_id":4,
    },
   
  ];

 public Cities:any[]=[
    {
      "id":1,
      "name":"Hyderabad",
      "country_id":1,
      "state_id":1
    },
    {
      "id":2,
      "name":"Amaravathi",
      "country_id":1,
      "state_id":2
    },
    {
      "id":3,
      "name":"Chennai",
      "country_id":1,
      "state_id":3
    },
    {
      "id":4,
      "name":"London",
      "country_id":2,
      "state_id":4
    }
  ]

  countryId:any;
  stateId:any;
  cityId:any;

  ngonInit(){
  }

  public changeCountry(){
   this.States=this.States.filter(item=>item.country_id==this.countryId);
  }
  public changeState(){
    this.Cities=this.Cities.filter(item=>item.state_id==this.stateId);
  }
}
